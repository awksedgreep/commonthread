# Build your own controller here
class MasterController < Controller
   # Optionally register web services, currently XML-RPC supported
   # Example:
   # register_xmlrpc :status, :producer_status, :consumer_status, :queue_status, :shutdown
end
